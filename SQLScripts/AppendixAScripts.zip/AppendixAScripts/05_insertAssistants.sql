INSERT INTO assistant VALUES (1, 'Betty Ross', 3);
INSERT INTO assistant VALUES (2, 'Jack Assistant', 2);
INSERT INTO assistant VALUES (3, 'Mr Assistant', 1);

SELECT * FROM assistant;