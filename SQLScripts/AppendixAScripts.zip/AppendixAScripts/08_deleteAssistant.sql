DELETE FROM assistant
WHERE assistant_id=3;


--To test that we cannot delete superhero with an assistant.
--DELETE FROM superhero
--WHERE superhero_id = 2;