DROP TABLE IF EXISTS superhero_power;

CREATE TABLE superhero_power(superhero_id serial REFERENCES superhero,
							 power_id serial REFERENCES hero_power,
							 PRIMARY KEY (superhero_id, power_id));