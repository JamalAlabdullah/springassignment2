INSERT INTO hero_power VALUES (1, 'Power 1', 'Strong');
INSERT INTO hero_power VALUES (2, 'Power 2', 'Laser eyes');
INSERT INTO hero_power VALUES (3, 'Power 3', 'Fireball');
INSERT INTO hero_power VALUES (4, 'Power 4', 'Invisibility');

INSERT INTO superhero_power (superhero_id, power_id) VALUES (1,1);
INSERT INTO superhero_power (superhero_id, power_id) VALUES (2,1);
INSERT INTO superhero_power (superhero_id, power_id) VALUES (3,4);
INSERT INTO superhero_power (superhero_id, power_id) VALUES (3,2);