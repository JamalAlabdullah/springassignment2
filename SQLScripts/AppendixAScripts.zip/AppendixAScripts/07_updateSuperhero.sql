UPDATE superhero
SET superhero_name = 'Mike Update'
WHERE superhero_id = 1;

SELECT * FROM superhero