INSERT INTO superhero VALUES (1, 'Kal-El', 'Superman', 'Krypton');
INSERT INTO superhero VALUES (2, 'Peter Parker', 'Spiderman', 'New York');
INSERT INTO superhero VALUES (3, 'Bruce Banner', 'Hulk', 'Ohio');
